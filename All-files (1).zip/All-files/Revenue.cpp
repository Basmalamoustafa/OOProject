#include "Revenue.h"
using namespace std;

Revenue::Revenue():cost1(0), income(0), revenue(0){}
Revenue::Revenue(double income, double cost1) {
	this->cost1 = cost1;
	this->income = income;
	revenue = income - cost1;
}
double Revenue::getIncome() {
	return income;
}
void Revenue::setIncome(double income) {
	this->income = income;
}
double Revenue::getCost() {
	return cost1;
}
void Revenue::setCost(double cost1) {
	this->cost1 = cost1;
}
bool Revenue::getIsProfitable(double income, double cost1){
	revenue = income - cost1;
	if (revenue > 0) return true;
	else return false;
}
double Revenue::getRevenue() {
	return revenue;
}
