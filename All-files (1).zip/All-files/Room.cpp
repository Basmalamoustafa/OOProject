#include "Room.h"
Room::Room() :price(0), roomNumber(0) {}