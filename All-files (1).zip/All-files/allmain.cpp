#include <iostream>
#include <string>

#include "Review.h"
#include "RoomAvailable.h"
#include "events.h"
#include "Revenue.h"
#include "laundry.h"
#include "HouseKeeping.h"
#include "Payment.h"
#include "guest.h"
#include "staff.h"
#include "staff_attendance.h"
#include "staff_salaries.h"

using namespace std;

int main(void) {
    
    // Room availability
    long int room_number;
    bool room_found = false;

    while (!room_found) {
        cout << "Enter the number of the room you want to book: ";
        cin >> room_number;
        cout << endl;

        //cout << "Choose the room's type (single/double/tripple): "<<endl;
        //cout << "Choose the room's view (Sea, Garden, Bay, Mountain): "<<endl;

        RoomAvailable guest(room_number);
        if (guest.isAvailable()) {
            cout << "The room " << room_number << " is available for booking!" << endl;
            room_found = true;
        } else {
            cout << "Sorry! This room isn't available" << endl;
        }
    }

    // guest info
    string guest_name, contact_num;
    long int natID;

    guest guest1;

    cout << "Enter the guest's name: ";
    cin >> guest_name;
    cout << "Enter the guest's contact number: ";
    cin >> contact_num;
    cout << "Enter the guest's ID: ";
    cin >> natID;

    guest1.set_name(guest_name);
    guest1.set_contactNum(contact_num);
    guest1.set_ID(natID);

    // displaying the guest data
    cout << endl << "Here is your info ......" <<endl;
    cout << endl << "Guest Name: "<<guest1.getName() <<endl << "Contact Number: " <<guest1.getContactNumber() << endl <<
    "Guest ID: "<<guest1.get_ID() << endl << "Guest Room: "<<guest1.getRoomNum() << endl;

    // payment
    //int amountt;
	int id;
	string method;
	payment person;

    //To check if the user entered negative amount
	//do {
		//cout << "enter the amount ";
		//cin >> amountt;
	//} while (amountt < 0); 
	//person.setAmount(amountt);
	cout << "enter the paymentID ";
	cin >> id;
	person.setPaymentID(id);
	cout << "enter payment Method to complete the process , cash or credit card ";
	cin >> method;
	person.setPaymentMethod(method);
	cout<<"The payment amount = " << person.getAmount() << endl << "The ID = " << person.getPaymentID() << endl << "The Method is:" << person.getPaymentMethod()<<endl;

    // housekeeping 
    houseKeeping person1;
	string need;
	int tota;

    cout << "Do you want the house keeping (yes/no)?" << endl;
	cin >> need;
	person1.setHouseKeepingNeed(need);
	bool check = person1.getHouseKeeping();
	if (check == true) {
		cout << "House keeping staff on their way to your room: " <<person1.getRoom()<<endl;
		person1.displayCost();
	}
	tota = person.getAmount() + person1.getCost();
	cout << "The total amount to pay = " << endl <<tota << endl;

    // laundry

    Laundry laundry;
    laundry.isLaundryStaff(true);
    string laundry_need;
    cout << "Do you need laundry today?(Y/N)  ";
    cin >> laundry_need; cout << endl;
    if (laundry_need == "Y" || laundry_need == "y") {
        laundry.setLaundry_need(true);

        if (laundry.isLaundryStaff(true)) {
        cout << "Laundry staff is available." << endl;
        laundry.setFinished(true);
        }
        else {
            cout << "Laundry staff is not available." << endl;
            laundry.setFinished(false);
        }
        string express;
        cout << "Do you want to use the express service?(Y/N)  ";
        cin >> express; cout << endl;
        if (express == "Y" || express == "y") laundry.setExpress(true);
        else laundry.setExpress(false);

        // display laundry ticket info
        cout << "Room " << laundry.getRoom() << " laundry status: "
         << (laundry.getLaundry() ? "Needed" : "Not Needed") << endl;
        cout << "Guest name: " << laundry.getGuest_name() << endl;
        cout << "Laundry is " << (laundry.getFinished() ? "Finished" : "Not Finished") << endl;
        cout << "Express: " << (laundry.getExpress() ? "Yes" : "No") << endl;
        cout << endl << endl << "Thank you for using our laundry service!" << endl;
    }
    else {
        laundry.setLaundry_need(false);
        cout << "Remeber that we are always available" << endl;
    }

    // events

    events new_year("New Year Party", "Friday");
    string registered_str, paid_str;
    bool registered, paid;
    cout << "Please enter your name: ";
    cin >> guest_name; cout << endl;
    long int guest_room = new_year.getRoom();

    cout << "Did you register for our New Year's Party? ";
    cin >> registered_str; cout << endl;
    if (registered_str == "yes") {
        registered = true;
    } else if (registered_str == "no") {
        registered = false;
        cout << "If you want to attend, register for the event either on our website or by going to the reception"<<endl;
        cout << "Do you want to register now? ";
        string response;
        cin >> response;
        if (response == "yes") {
            registered = true;
        } else if (response == "no") {
            registered = false;
            cout << "You can't attend the event without registering." << endl;
            return 0;
        } else {
            cout << "Invalid input. Please enter 'yes' or 'no'." << endl;
            return 0;
        }
    } else {
        cout << "Invalid input. Please enter 'yes' or 'no'." << endl;
        return 0;
    }
    if (registered) {
        cout << "Did you pay the fees? ";
        cin >> paid_str; cout << endl;
        if (paid_str == "yes") {
            paid = true;
        } else if (paid_str == "no") {
            paid = false;
        } else {
            cout << "Invalid input. Please enter 'yes' or 'no'." << endl;
            return 0;
        }
        new_year.payment(paid, guest_name, guest_room);
    }

    // staff

    string name, position, section;
	long int staffID;
	double salary;

	cout << "Please enter employee's name:"<<endl;
	cin >> name;
	cout << "Please enter employee's position:" << endl;
	cin >> position;
	cout << "Please enter employee's section:" << endl;
	cin >> section;
	cout << "Please enter their salary:" << endl;
	cin >> salary;
	cout << "Please enter their ID:" << endl;
	cin >> staffID;
   
	staff employee1;
	
	employee1.setName(name);
	employee1.setID(staffID);
	employee1.setPosition(position);
	employee1.setSection(section);
	employee1.setSalary(salary);
	
	
	cout << "Employee's name:" << employee1.getName() << endl;
	cout << "ID:" << employee1.getID() << endl;
	cout << "Position:" << employee1.getPosition() << endl;
	cout << "Section:" << employee1.getSection() << endl;
	cout << "Salary:" << employee1.getSalary() << endl;

    // staff salaries
    double bonus, tax, gross, net;
	
	
	cout << "Please enter gross salary:" << endl;
	cin >> gross;
	cout << "Please enter tax: " << endl;
	cin >> tax;
	cout << "Please enter bonus amount:" << endl;
	cin >> bonus;
	
	net = gross + bonus - tax;

	staff_salaries salary1;
	
	salary1.set_gross(gross);
	salary1.set_tax(tax);
	salary1.set_gross(bonus);
	salary1.set_gross(net);

	cout << "Employee's gross salary:" << gross << endl;
	cout << "Employee's tax amount:" << tax << endl;
	cout << "Employee's bonus amount:" << bonus << endl;
	cout << "Employee's net salary:" << net << endl;

    // revenue
    // this class is supposed to be connected with the heads class, which will be implemented later
    Revenue r1;
    double cost1, income;
    cout << "\nplease enter the hotel's costs";
    cin >> cost1;
    cout << "\n"<<"please enter the hotel's income";
    cin >> income;
    r1.setCost(cost1);
    r1.setIncome(income);
    if (r1.getIsProfitable(income, cost1) == true) {
        cout << "\n"<<"The hotel is profitable with "<< r1.getRevenue()<<" EGP revenue";
    }
    else cout << "\n" << "The hotel is not profitable with " << -1 * r1.getRevenue() << " EGP loss";

    // review

    Review review1;
    long int reviewID=1, bookingID;
    int rating;
    string reviewText;
    cout << "\n" << "please enter you booking id: ";
    cin >> bookingID;
    cout << "\n" << "please enter you rating out of 5: ";
    cin >> rating;
    cout << "\n" << "please enter you review in text: ";
    cin >> reviewText;
    review1.setRating(rating);
    review1.setReviewID(reviewID);
    review1.setReview(reviewText);
    review1.setBookingID(bookingID);

    return 0;
}