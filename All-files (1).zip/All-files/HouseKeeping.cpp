#include "houseKeeping.h"
using namespace std;
#include <iostream>
void houseKeeping::setHouseKeepingNeed(string need)
{
	if (need == "yes" || need == "Yes" || need == "YES" ) {
		HouseKeepingNeed = true;
	}
	else {
		HouseKeepingNeed = false;
	}
}

bool houseKeeping::getHouseKeeping()
{
	if (HouseKeepingNeed == true)
		counter += 1;
	return HouseKeepingNeed;
}

void houseKeeping::displayCost()
{
	cost = counter * 20;
	cout << "\"the cost per 1 time = 20$\"";
	cout << "The Total cost is " << cost << "$";
}

houseKeeping::houseKeeping()
{
	HouseKeepingNeed = false;
	cost = 0;
	counter = 0;
}

int houseKeeping::getCost()
{
	return cost;
}
long int houseKeeping::getRoom() {
	return getRoomNum();
}