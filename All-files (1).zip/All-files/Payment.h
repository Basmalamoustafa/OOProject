#pragma once
#include <string>
#include "houseKeeping.h"
using namespace std;
class payment
{
private:
	int paymentID;
	double amount;
	string paymentMethod;
	int total;
public:
	payment();
	void setPaymentID(int ID);
	int getPaymentID();
	void setAmount(double amount1);
	double getAmount();
	void setPaymentMethod(const string& paymentMethodd);
	string getPaymentMethod();
};

