#pragma once
class Revenue
{
private:
	double income, cost1, revenue;
	bool isProfitable;
public:
	Revenue();
	Revenue(double income, double cost1);
	double getIncome();
	void setIncome(double income);
	double getCost();
	void setCost(double cost1);
	bool getIsProfitable(double income, double cost1);
	double getRevenue();
};

