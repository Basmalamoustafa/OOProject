#include "RoomAvailable.h"
using namespace std;

RoomAvailable::RoomAvailable(long int room_number) {
    this->room_number = room_number;
}

bool RoomAvailable::isAvailable() {
    for (int i = 0; i < 15; i++) {
        if (room_number == availableRooms[i]) {
            return true;
        }
    }
    return false;
}

long int RoomAvailable::getRoomNum() {
    return this->room_number;
}
void RoomAvailable::setRoom(long int room_number) {
    this->room_number = room_number;
}
void RoomAvailable::setType(roomType type) {
    this->typeRoom = type;
}
string RoomAvailable::getType() {
    return typeRoom;
}
void RoomAvailable::setView(roomView view) {
    this->viewRoom = view;
}
string RoomAvailable::getView() {
    return viewRoom;
}
double RoomAvailable::getPrice() {
    return price;
}