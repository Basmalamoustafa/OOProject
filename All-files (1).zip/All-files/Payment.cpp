#include "payment.h"
#include <iostream>
using namespace std;
payment::payment()
{
	paymentID = 0;
	amount = 0;
	paymentMethod = " ";
}

//To get the paymentID from the user
void payment::setPaymentID(int ID)
{
	paymentID = ID;
}

int payment::getPaymentID()
{
	return paymentID;
}

//To take the amount of money the user will pay
void payment::setAmount(double amount1)
{
	amount = amount1;
}

//To ask the user if he will pay in cash or credit card
double payment::getAmount()
{
	return amount;
}

void payment::setPaymentMethod(const string& paymentMethodd)
{
	paymentMethod = paymentMethodd;
}

string payment::getPaymentMethod()
{
	return paymentMethod;
}
