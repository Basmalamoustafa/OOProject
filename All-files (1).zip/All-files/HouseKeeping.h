#pragma once
#include <string>
#include "RoomAvailable.h"
using namespace std;
class houseKeeping : public RoomAvailable
{
protected:
	int RoomNumber;
	double cost;
	bool HouseKeepingNeed;
	int counter;
public:
//To check if you need the house keeping or not 
	void setHouseKeepingNeed(string need);
	bool getHouseKeeping();
	//to display the cost of house keeping
	void displayCost();
	houseKeeping();
//to get the cost to add it in the payment
	int getCost();
	long int getRoom();
};

