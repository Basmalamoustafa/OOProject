#include <iostream>
#include <string>
#include "guest.h"
using namespace std;


int main()
{
   
}
